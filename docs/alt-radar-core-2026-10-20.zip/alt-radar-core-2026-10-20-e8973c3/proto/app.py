"""
ALT RADAR - live scanner.

Continuous refresh against MEXC with a curses TUI: ranked LONG/SHORT table,
detail view with the full scoring breakdown and trade plan, and veto visibility.

    python3 -m proto.app --stake 0.10 --coins 150 --interval 60
    python3 -m proto.app --use-v3 --log-threshold 40  # v3 shadow score mode

Keys: arrows select | ENTER detail | d long/short/both | s sort | p pause |
      w watcher | W write logs | q quit

Read-only. Places no orders, holds no keys.
"""

import argparse
import curses
import sys
import time

from . import mexc
from . import scan as scanmod
from . import indicators as ind
from . import planner as pl
from .scan import build_universe, score_universe, venue_health
from .store import Store, writes_signals
from . import watcher_journal as journalmod
from .watcher_feed import WatcherUnavailable, correlated_lines, load_panel
from .watcher_view import RESEARCH_BANNER

SORT_KEYS = {
    "score": lambda c: -c.score,
    "early": lambda c: -c.earlyness,
    "lean": lambda c: -abs(c.lean),
    "move": lambda c: -abs(c.change_24h_pct),
    "vol": lambda c: -c.quote_vol_24h,
}

# Universe feed cache (spec SS3): tickers+details+Bybit map refresh at most
# every 10 minutes in memory. Excluded from the 90s scan gate - only the
# per-coin fetch+score in scan_once is inside that budget.
UNIVERSE_TTL = 180


class App:
    def __init__(self, args):
        self.args = args
        self.cards = []
        self.sel = 0
        self.detail = False
        self.dir_filter = "both"     # both | long | short
        self.sort_key = "score"
        self.use_v3 = getattr(args, "use_v3", False)
        self.paused = False
        self.status = "starting..."
        self.last_scan = 0.0
        self.store = Store(args.db)
        self.uni = []
        self.det = {}
        self.tk = {}
        self.failed = 0              # per-coin failures, last scan_once
        self.last_errors = {}        # {coin: reason} from the last scan_once
        self.log_errors = 0          # store write failures, last scan_once
        self.universe_error = None   # last universe refresh failure, if any
        self._uni_at = 0.0           # when self.uni was last refreshed
        self.sweep_progress = (0, 0)  # (done, total) of the latest sweep
        # Watcher screen (additive; scanner state above untouched).
        self.show_watcher = False
        self.watcher_detail = False
        self.watcher_selected = None  # setup id, never a row index
        self.watcher_panel = None
        self.watcher_error = None

    # ---------- data ----------
    def refresh_universe(self):
        # Stakeless full universe (dashboard spec section 2): every eligible
        # perp, every refresh. `universe_budget` is an OPTIONAL front-end hook
        # (the GUI ties it to its --coins control); absent, the sweep walks
        # the whole eligible set. One Bybit ticker request per refresh fills
        # the OI symbol map the per-coin OI leg reads (never per coin).
        budget = getattr(self.args, "universe_budget", None)
        self.uni = build_universe(budget=budget, store=self.store)
        scanmod._bybit_symbol_set()
        self.det = mexc.details()
        self.tk = mexc.tickers()
        self._uni_at = time.time()

    def maybe_refresh_universe(self):
        """Refresh the universe feed only when the 10-minute cache expired.

        A failed refresh keeps the last good universe and is surfaced in
        status - never a silent crash of the loop.
        """
        if time.time() - self._uni_at <= UNIVERSE_TTL:
            return
        try:
            self.refresh_universe()
            self.universe_error = None
        except Exception as e:
            self.universe_error = f"{type(e).__name__}: {e}"
            if not self.uni:
                self.status = f"universe unavailable: {self.universe_error}"

    def degraded_text(self):
        """Header marker for venues whose last universe fetch failed (SS6)."""
        bad = [v.upper() for v, st in venue_health().items() if not st["ok"]]
        return "".join(f" · ⚠ {v} DEGRADED" for v in bad)

    def scan_once(self, record_sweep=True):
        # The 90s gate covers the per-coin fetch+score ONLY; the universe
        # feed above is cached 10 minutes and excluded from that budget.
        # Phase timing (monotonic so NTP steps cannot skew it): read off
        # self.last_scan_phases after the call. No behavior change.
        # ``record_sweep`` (WS-F): the CLI/TUI path keeps writing its own
        # sweep-complete journal event + dashboard snapshot row; the daemon
        # passes False because it records the sweep itself (one row per
        # completed iteration, never two).
        total_t0 = time.monotonic()
        t_uni = time.monotonic()
        self.maybe_refresh_universe()
        universe_refresh_s = time.monotonic() - t_uni
        t0 = time.time()
        ranked = sorted(
            self.uni,
            key=lambda s: scanmod._fnum(self.tk.get(s[0], {}).get("amount24")),
            reverse=True)[: self.args.coins]

        errors = {}
        self.sweep_progress = (0, len(ranked))

        def _progress(done, total):
            self.sweep_progress = (done, total)

        t_score = time.monotonic()
        cards = score_universe(ranked, self.det, self.tk, self.args.stake,
                               errors=errors,
                               stagger=scanmod.STAGGER_S,
                               max_workers=scanmod.MAX_WORKERS,
                               attach_plans=True,
                               max_leverage=getattr(
                                   self.args, "leverage_cap",
                                   pl.MAX_LEVERAGE),
                               progress_fn=_progress)
        score_s = time.monotonic() - t_score

        # Log: flagged rows AND shadow rows (vetoed / sub-threshold). SS6.1a.
        # Flagged = stake-aware actionable AND above threshold (selective,
        # not permissive): a None min_notional never flags (fail-closed).
        # Flagged rows also freeze their trade plan (levels at score time)
        # so stop/TP1/TP2 hits become measurable facts, not estimates.
        # Log write failures are counted too - never swallowed silently.
        log_errors = 0
        t_log = time.monotonic()
        if self.args.write_logs:
            for sc in cards:
                score_val = sc.score_v3 if (self.use_v3 and sc.score_v3 is not None) else sc.score
                threshold = self.args.log_threshold
                flagged = (sc.is_actionable(self.args.stake)
                           and score_val is not None
                           and score_val >= threshold)
                try:
                    fv = 3 if self.use_v3 else 2
                    # Epoch gate (Task 1, spec section 1): after the cut to
                    # watcher-only the scan loop may still fetch for
                    # universe/freshness display, but writes no signals.
                    sid = None
                    if writes_signals(self.store.conn):
                        sid = self.store.log_signal(sc, flagged=flagged,
                                                    tier=2, flag_version=fv)
                    plan = getattr(sc, "plan", None)
                    if flagged and plan is not None and getattr(
                            plan, "valid", False):
                        if writes_signals(self.store.conn):
                            self.store.log_plan(sid, plan)
                    # Board upkeep: the coin's single current row follows
                    # every scan (journal above keeps the full history).
                    # Frozen too while a watcher-only epoch is active.
                    if writes_signals(self.store.conn):
                        self.store.upsert_current(sc, flagged, sid, tier=2)
                except Exception:
                    log_errors += 1
        log_s = time.monotonic() - t_log

        self.failed = len(errors)
        self.last_errors = errors
        self.log_errors = log_errors
        self.cards = cards
        self.sel = 0
        self.last_scan = time.time()
        # Post-cut writer (Task 3, spec section 1): every completed sweep
        # logs a sweep-complete journal event + a dashboard snapshot row
        # carrying eligible vs evaluated counts separately.  The daemon
        # suppresses it (record_sweep=False) and writes exactly one row of
        # each itself.
        evaluated = len(ranked)
        eligible = len(self.uni)
        self.sweep_progress = (evaluated, evaluated)
        if record_sweep:
            journalmod.record_sweep(self.store.conn, eligible, evaluated)
        self.status = (f"sweeping {evaluated}/{eligible} · "
                       f"scored {len(cards)} in {time.time()-t0:.0f}s · "
                       f"universe {len(self.uni)} · "
                       f"failed {len(errors)}/{len(ranked)}"
                       + (f" · log errors {log_errors}" if log_errors else "")
                       + (f" · universe ERROR {self.universe_error}"
                          if self.universe_error else "")
                       + self.degraded_text())
        self.last_scan_phases = {
            "universe_refresh_s": float(universe_refresh_s),
            "score_s": float(score_s),
            "log_s": float(log_s),
            "total_s": float(time.monotonic() - total_t0),
        }

    def visible(self):
        """Ranked rows: non-vetoed only. Vetoes get their own section (SS6)."""
        out = [c for c in self.cards if not c.vetoes]
        if self.dir_filter == "long":
            out = [c for c in out if c.direction == "LONG"]
        elif self.dir_filter == "short":
            out = [c for c in out if c.direction == "SHORT"]
        return sorted(out, key=SORT_KEYS[self.sort_key])

    def vetoed(self):
        """Vetoed rows, excluded from ranking but still visible + logged."""
        out = [c for c in self.cards if c.vetoes]
        if self.dir_filter == "long":
            out = [c for c in out if c.direction == "LONG"]
        elif self.dir_filter == "short":
            out = [c for c in out if c.direction == "SHORT"]
        return sorted(out, key=SORT_KEYS[self.sort_key])

    def plan_for(self, card):
        sym_lookup = dict((cn, sy) for sy, cn in self.uni)
        if card.coin not in sym_lookup:
            return None, None
        try:
            bars = mexc.klines(sym_lookup[card.coin], "5m", limit=200)
            swing = (ind.swing_low(bars) if card.direction == "LONG"
                     else ind.swing_high(bars))
            if swing is None:
                swing = bars[-1]["l"] if card.direction == "LONG" else bars[-1]["h"]
            return pl.build_plan(card, stake=self.args.stake, swing_ref=swing,
                                 funding_rate=card.funding_rate,
                                 max_leverage=getattr(
                                     self.args, "leverage_cap",
                                     pl.MAX_LEVERAGE)), bars
        except Exception as e:
            return None, str(e)

    # ---------- rendering ----------
    def draw_table(self, stdscr, h, w):
        rows = self.visible()
        cw = stdscr
        cw.erase()
        cw.border(0)

        paused = " PAUSED" if self.paused else ""
        cw.addstr(0, 2, f" ALT RADAR · MEXC perp scanner · live · read-only"
                        f" · TIER-2 UNVALIDATED{paused} "[:w - 4])
        st = self.store.stats()
        cw.addstr(1, 2, f" universe {len(self.uni)} · shown {len(rows)} · "
                        f"sort {self.sort_key} · dir {self.dir_filter} · "
                        f"stake ${self.args.stake:.2f}".ljust(w - 4))
        cw.addstr(2, 2, f" logs: {st['rows']} rows / {st['coins']} coins · "
                        f"flagged {st['flagged']} · L {st['longs']} / S {st['shorts']} · "
                        f"{self.status}".ljust(w - 4))

        header = (f"{'#':<3}{'DIR':<5}{'COIN':<15}{'PRICE':>13}{'24H%':>8}"
                  f"{'VOL24':>10}{'LEAN':>7}{'EARLY':>7}{'SCORE':>7}{'V3':>7}  FLAGS")
        cw.addstr(4, 2, header[:w - 4], curses.A_BOLD)
        cw.hline(5, 2, curses.ACS_HLINE, w - 4)

        vet = self.vetoed()
        # Reserve room for the vetoed section (header + up to 3 rows) so the
        # ranked list never pushes it off-screen.
        veto_lines = (2 + min(len(vet), 3)) if vet else 0
        body_h = max(1, h - 9 - veto_lines)
        start = 0
        if self.sel >= body_h:
            start = self.sel - body_h + 1
        for i, c in enumerate(rows[start:start + body_h]):
            y = 6 + (i - start)
            arrow = {"LONG": "▲", "SHORT": "▼"}.get(c.direction, "•")
            vol = c.quote_vol_24h
            vol_s = f"${vol/1e6:.1f}M" if vol >= 1e6 else f"${vol/1e3:.0f}K"
            # Stakeless model (spec section 2): min_notional is venue info
            # for detail display, never a flag. No stake gating here.
            flags = []
            attr = curses.A_REVERSE if (i + start) == self.sel else curses.A_NORMAL
            v3_display = (f"{c.score_v3:>7.1f}" if getattr(c, "score_v3", None) is not None else f"{'—':>7}")
            line = (f"{i+start+1:<3}{arrow:<5}{c.coin:<15}{c.price:>13.8g}"
                    f"{c.change_24h_pct:>7.1f}%{vol_s:>10}{c.lean:>7.2f}"
                    f"{c.earlyness:>7.2f}{c.score:>7.1f}{v3_display}  {' '.join(flags)}")
            try:
                cw.addstr(y, 2, line[:w - 4], attr)
            except curses.error:
                pass

        # Vetoed section: excluded from ranking, still visible + shadow-logged
        # (spec SS5/SS6) - a vetoed coin that later pumps must leave a trace.
        y = 6 + body_h
        if vet and y < h - 3:
            try:
                cw.addstr(y, 2, (f"── VETOED · {len(vet)} excluded from "
                                 f"ranking, shadow-logged ──")[:w - 4],
                          curses.A_DIM)
            except curses.error:
                pass
            y += 1
        for c in vet[:max(0, h - 3 - y)]:
            arrow = {"LONG": "▲", "SHORT": "▼"}.get(c.direction, "•")
            codes = ",".join(v.code for v in c.vetoes)
            line = f"   {arrow} {c.coin:<15}{c.score:>7.1f}  veto:{codes}"
            try:
                cw.addstr(y, 2, line[:w - 4], curses.A_DIM)
            except curses.error:
                pass
            y += 1

        help_txt = ("↑↓ select  ENTER detail  d long/short/both  s sort  "
                    "p pause  w watcher  q quit")
        cw.addstr(h - 2, 2, help_txt[:w - 4])
        cw.refresh()

    def draw_detail(self, stdscr, h, w):
        rows = self.visible()
        if not rows:
            return
        card = rows[min(self.sel, len(rows) - 1)]
        plan, err = self.plan_for(card)

        cw = stdscr
        cw.erase()
        cw.border(0)
        arrow = {"LONG": "▲", "SHORT": "▼"}.get(card.direction, "•")
        cw.addstr(0, 2, (f"{card.coin} {arrow} {card.direction} · score {card.score}"
                         + (f" · v3 {card.score_v3}" if getattr(card, "score_v3", None) is not None else "")
                         + f" · lean {card.lean:+.2f} · earlyness {card.earlyness:.2f}"
                         + f"  [ENTER back]").ljust(w - 4), curses.A_BOLD)
        cw.hline(1, 2, curses.ACS_HLINE, w - 4)

        y = 3
        def put(s, attr=curses.A_NORMAL):
            nonlocal y
            if y < h - 2:
                try:
                    cw.addstr(y, 2, s[:w - 4], attr)
                except curses.error:
                    pass
                y += 1

        put("SCORE COMPONENTS          MAGNITUDE   LEAN")
        for k in ("VOL", "BOOK", "OI"):
            mv = card.magnitude_parts.get(k)
            lv = card.lean_parts.get(k)
            put(f"  {k:<22} {('%.1f' % (mv*100)) if mv is not None else '  n/a':>8}"
                f"   {(('%+.2f' % lv) if lv is not None else 'n/a'):>7}")
        put("")
        put(f"  earlyness {card.earlyness:.2f}   ·   24h {card.change_24h_pct:+.1f}%"
            f"   ·   vol24 ${card.quote_vol_24h:,.0f}"
            f"   ·   spread {card.spread_pct:.2f}%"
            f"   ·   funding {card.funding_rate*100:+.4f}%")
        _oi = card.oi_change_pct
        _oin = getattr(card, "oi_notional", None)
        if _oi is None:
            put("  ⚠ OI unavailable on MEXC — OI/FUNDING signal is running on "
                "funding alone", curses.A_DIM)
        elif _oin is not None:
            put(f"  OIΔ {_oi:+.1f}% on ~${_oin:,.0f} open interest — judge the "
                f"percent against this base", curses.A_DIM)
        if any(isinstance(n, str) and "UNVALIDATED" in n for n in card.notes):
            put("  ⚠ TIER 2 · UNVALIDATED — no outcome history exists for this "
                "score yet; treat as experimental", curses.A_DIM)
        # v3 shadow score detail
        if getattr(card, "score_v3", None) is not None:
            v3_init = getattr(card, "initiation", None)
            v3_flow = getattr(card, "flow_state", None)
            v3_dir = getattr(card, "direction_v3", None)
            v3_parts = getattr(card, "v3_parts", {})
            put(f"  v3 shadow: score_v3={card.score_v3}  dir_v3={v3_dir}"
                + (f"  initiation={v3_init:.2f}" if v3_init is not None else "")
                + (f"  flow={v3_flow}" if v3_flow else ""))
            if v3_parts:
                put(f"  v3 parts: activity={v3_parts.get('activity','?')}"
                    f" location={v3_parts.get('location','?')}"
                    f" opening_for={v3_parts.get('opening_for','?')}"
                    f" book_agree={v3_parts.get('book_agree','?')}"
                    + (f" htf_aligned={v3_parts.get('htf_aligned','?')}" if 'htf_aligned' in v3_parts else ""))
        if card.coin in self.last_errors:
            put(f"  ⚠ last error: {self.last_errors[card.coin]}", curses.A_DIM)
        # Counter-trend labels are surfaced, never swallowed (spec SS4) —
        # they reach plan warnings when a plan exists; show them here too so
        # an unplannable coin still carries the risk label.
        for n in card.notes:
            if isinstance(n, str) and (n.startswith("counter-trend:") or
                                       n.startswith("MTF ") or
                                       n.startswith("DATA ")):
                put(f"  ⚠ {n}", curses.A_BOLD)
        put("")

        if card.vetoes:
            put("VETOES", curses.A_BOLD)
            for v in card.vetoes:
                put(f"  ⨯ {v.code}: {v.reason}")
            put("")

        if plan:
            put("TRADE PLAN (review only — this app places no orders)", curses.A_BOLD)
            for line in pl.format_plan(plan, card).splitlines():
                attr = curses.A_BOLD if line.strip().startswith("⚠") else curses.A_NORMAL
                put(line, attr)
        elif err:
            put(f"no plan: {err}")
        else:
            put("no plan available")

        cw.addstr(h - 2, 2, "ENTER back   q quit"[:w - 4])
        cw.refresh()

    # ---------- watcher screen (additive; scanner draws/keys untouched) ----------
    def watcher_order(self, panel):
        """Setup ids, active first — the single order every watcher
        surface walks (selection indexes this, never row position)."""
        order = []
        for key in ("active", "unavailable", "invalidated", "expired",
                    "resolved"):
            order.extend(panel.groups.get(key, []))
        return order

    def refresh_watcher(self):
        """Reload the watcher panel from the DB (read-only feed).

        Selection stays pinned to the setup id across reloads. Any
        failure is contained: panel None + error text, scanner intact.
        """
        try:
            self.watcher_panel = load_panel(self.args.db,
                                            selected_id=self.watcher_selected)
            if self.watcher_panel.selected_id is not None:
                self.watcher_selected = self.watcher_panel.selected_id
            self.watcher_error = None
        except WatcherUnavailable as e:
            self.watcher_panel = None
            self.watcher_error = str(e)
        except Exception as e:  # noqa: BLE001 - draw path must never crash
            self.watcher_panel = None
            self.watcher_error = f"{type(e).__name__}: {e}"
        return self.watcher_panel

    def _watcher_move(self, delta):
        panel = self.watcher_panel
        if panel is None:
            return
        order = self.watcher_order(panel)
        if not order:
            return
        if self.watcher_selected not in order:
            self.watcher_selected = order[0]
            return
        i = order.index(self.watcher_selected)
        self.watcher_selected = order[min(len(order) - 1, max(0, i + delta))]

    def on_key(self, ch):
        """Minimal key-dispatch seam: watcher keys consumed here.

        Returns True when handled; False lets the main loop apply the
        existing scanner branches untouched. Note: ``w`` now toggles
        the watcher screen (previously the write-logs toggle); the
        logging itself (scan_once writes) is untouched and its toggle
        lives on ``W``.
        """
        if ch == ord("w"):
            if self.watcher_detail:
                self.watcher_detail = False
            else:
                self.show_watcher = not self.show_watcher
                if self.show_watcher:
                    self.refresh_watcher()
            return True
        if ch == ord("W"):
            self.args.write_logs = not self.args.write_logs
            self.status = ("logging ON (flagged + shadow)"
                           if self.args.write_logs else "logging OFF")
            return True
        if not self.show_watcher:
            return False
        if ch == 27:
            self.show_watcher = False
            self.watcher_detail = False
            return True
        if ch in (ord("\n"), ord("j")):
            self.watcher_detail = not self.watcher_detail
            return True
        if ch == curses.KEY_DOWN:
            self._watcher_move(1)
            return True
        if ch == curses.KEY_UP:
            self._watcher_move(-1)
            return True
        return False

    @staticmethod
    def _fmt_px(v):
        return f"{v:.8g}" if isinstance(v, (int, float)) else "—"

    def draw_watcher(self, stdscr, h, w):
        cw = stdscr
        cw.erase()
        cw.border(0)
        if self.watcher_panel is None and self.watcher_error is None:
            self.refresh_watcher()
        panel = self.watcher_panel

        cw.addstr(0, 2, (" ALT RADAR · WATCHER setups · research, shadow-only"
                         " · read-only ")[:w - 4], curses.A_BOLD)
        if panel is None:
            try:
                cw.addstr(2, 2, " watcher data unavailable — scanner intact"
                                " (DB missing or locked)".ljust(w - 4))
                if self.watcher_error:
                    cw.addstr(3, 2, f" {self.watcher_error}"[:w - 4],
                              curses.A_DIM)
            except curses.error:
                pass
            cw.addstr(h - 2, 2, "w/ESC scanner  q quit"[:w - 4])
            cw.refresh()
            return

        banner = panel.notices[0] if panel.notices else RESEARCH_BANNER
        cw.addstr(1, 2, f" {banner}".ljust(w - 4))
        asof = f"data as of {panel.asof_ts}" if panel.asof_ts else "no data yet"
        last = (f" · last closed bar {panel.last_bar_ts}"
                if panel.last_bar_ts is not None else "")
        try:
            cw.addstr(2, 2, f" {asof}{last}".ljust(w - 4), curses.A_DIM)
        except curses.error:
            pass

        header = (f"{'ID':<10}{'RULE':<12}{'COIN':<10}{'DIR':<6}"
                  f"{'STATE':<12}ENTRY→STOP/TGT")
        cw.addstr(4, 2, header[:w - 4], curses.A_BOLD)
        # Plain "-" (not curses.ACS_HLINE): this screen must render on a
        # fake stdscr with no curses init in tests.
        cw.hline(5, 2, "-", w - 4)

        order = self.watcher_order(panel)
        if self.watcher_selected not in panel.by_id and order:
            self.watcher_selected = order[0]
        body_h = max(1, h - 9)
        start = 0
        try:
            cur = order.index(self.watcher_selected) if order else 0
        except ValueError:
            cur = 0
        if cur >= body_h:
            start = cur - body_h + 1
        for i, sid in enumerate(order[start:start + body_h]):
            y = 6 + (i - start)
            d = panel.by_id.get(sid, {})
            line = (f"{sid[-10:]:<10}{str(d.get('rule', '?')):<12}"
                    f"{str(d.get('coin', '?')):<10}"
                    f"{str(d.get('direction', '?')):<6}"
                    f"{d.get('state', '?'):<12}"
                    f"{self._fmt_px(d.get('entry'))}→"
                    f"{self._fmt_px(d.get('stop_px'))}/"
                    f"{self._fmt_px(d.get('tgt_px'))}")
            attr = (curses.A_REVERSE if sid == self.watcher_selected
                    else curses.A_NORMAL)
            try:
                cw.addstr(y, 2, line[:w - 4], attr)
            except curses.error:
                pass

        help_txt = ("↑↓ select  ENTER detail  w/ESC scanner  q quit")
        y_corr = 6 + len(order[start:start + body_h])
        for line in correlated_lines(self.args.db):
            if y_corr >= h - 2:
                break
            try:
                cw.addstr(y_corr, 2, line[:w - 4], curses.A_DIM)
            except curses.error:
                pass
            y_corr += 1
        cw.addstr(h - 2, 2, help_txt[:w - 4])
        cw.refresh()

    def draw_watcher_detail(self, stdscr, h, w):
        panel = self.watcher_panel
        if panel is None:
            self.draw_watcher(stdscr, h, w)
            return
        d = panel.by_id.get(self.watcher_selected)
        if d is None:
            self.draw_watcher(stdscr, h, w)
            return

        cw = stdscr
        cw.erase()
        cw.border(0)
        cw.addstr(0, 2, (f"{d.get('coin', '?')} {d.get('direction', '?')} · "
                         f"{d.get('state', '?')}  [ENTER back]").ljust(w - 4),
                  curses.A_BOLD)
        # Plain "-" (not curses.ACS_HLINE): no-curses-init test rendering.
        cw.hline(1, 2, "-", w - 4)

        y = 3

        def put(s, attr=curses.A_NORMAL):
            nonlocal y
            if y < h - 2:
                try:
                    cw.addstr(y, 2, s[:w - 4], attr)
                except curses.error:
                    pass
                y += 1

        for n in panel.notices:
            put(n, curses.A_BOLD)
        put("")
        put(f"  rule {d.get('rule', '?')} · src bar {d.get('src_bar_ts', '?')}"
            f" · monitoring {d.get('monitoring', '?')}")
        put(f"  entry {self._fmt_px(d.get('entry'))} · stop "
            f"{self._fmt_px(d.get('stop_px'))} · tgt "
            f"{self._fmt_px(d.get('tgt_px'))} · invalid "
            f"{self._fmt_px(d.get('invalid_price'))}")
        put(f"  state {d.get('state', '?')}")
        if d.get("missing"):
            put(f"  missing/stale: {', '.join(map(str, d['missing']))}",
                curses.A_DIM)
        cost = d.get("cost") or {}
        put(f"  cost total {cost.get('total', '?')} · floor "
            f"{cost.get('floor', '?')} · funding "
            f"{cost.get('funding_state', '?')}", curses.A_DIM)
        put(f"  ev_r {d.get('ev_r', '?')} · p_lb {d.get('p_lb', '?')} · "
            f"shadow {'yes' if d.get('shadow_selected') else 'no'}",
            curses.A_DIM)
        asof = (f"data as of {panel.asof_ts}" if panel.asof_ts
                else "no data yet")
        last = (f" · last closed bar {panel.last_bar_ts}"
                if panel.last_bar_ts is not None else "")
        put(f"  {asof}{last}", curses.A_DIM)
        corr = correlated_lines(self.args.db)
        if corr:
            put("")
            for line in corr:
                put(line, curses.A_DIM)

        cw.addstr(h - 2, 2, "ENTER back   w/ESC scanner   q quit"[:w - 4])
        cw.refresh()

    # ---------- loop ----------
    def loop(self, stdscr):
        curses.curs_set(0)
        stdscr.nodelay(True)
        try:
            from .snapshot import load as _load
            saved, _, _ = _load(self.args.db)
            if saved:
                self.cards = list(saved)
                self.status = (f"showing saved ({len(saved)} coins) — "
                               f"live scan running…")
        except Exception:
            pass
        self.refresh_universe()

        while True:
            if not self.paused and (time.time() - self.last_scan >
                                    self.args.interval):
                self.scan_once()

            h, w = stdscr.getmaxyx()
            if self.show_watcher:
                if self.watcher_detail:
                    self.draw_watcher_detail(stdscr, h, w)
                else:
                    self.draw_watcher(stdscr, h, w)
            elif self.detail:
                self.draw_detail(stdscr, h, w)
            else:
                self.draw_table(stdscr, h, w)

            ch = stdscr.getch()
            if ch == -1:
                time.sleep(0.4)
                continue
            if self.on_key(ch):
                continue
            if ch in (ord("q"), 27):
                from . import snapshot as _snap
                _snap.save(self.args.db, self.cards)
                return
            if ch == ord("p"):
                self.paused = not self.paused
                self.status = "paused" if self.paused else "resumed"
            elif ch == ord("d"):
                self.dir_filter = {"both": "long", "long": "short",
                                   "short": "both"}[self.dir_filter]
                self.sel = 0
            elif ch == ord("s"):
                order = list(SORT_KEYS)
                self.sort_key = order[(order.index(self.sort_key) + 1) % len(order)]
                self.sel = 0
            elif ch in (ord("\n"), ord("j")) and not self.detail:
                self.detail = True
            elif ch == ord("\n") and self.detail:
                self.detail = False
            elif ch == curses.KEY_DOWN:
                self.sel = min(self.sel + 1, max(0, len(self.visible()) - 1))
            elif ch == curses.KEY_UP:
                self.sel = max(0, self.sel - 1)


def run_headless(app, iterations=None):
    """
    Non-curses loop for environments without a real TTY (cron, systemd, CI,
    piping to a file). Prints a table per cycle and keeps logging.

    The TUI is the primary surface, but the scanner must not be hostage to a
    terminal: curses.wrapper() raises if stdin is not a tty, which is exactly
    the situation under a service manager or a piped invocation.
    """
    n = 0
    try:
        while iterations is None or n < iterations:
            # scan_once refreshes the universe itself when the 10-minute
            # cache expires, so every cycle stays inside the same contract.
            app.scan_once()
            rows = app.visible()
            st = app.store.stats()

            print(f"\n{'='*100}")
            print(f" ALT RADAR · {time.strftime('%Y-%m-%d %H:%M:%S')} · MEXC · "
                  f"stake ${app.args.stake:.2f} · read-only · TIER-2 UNVALIDATED")
            print(f" universe {len(app.uni)} · shown {len(rows)} · "
                  f"vetoed {len(app.vetoed())} · "
                  f"sort {app.sort_key} · dir {app.dir_filter}")
            print(f" logs {st['rows']} rows / {st['coins']} coins · "
                  f"flagged {st['flagged']} · L {st['longs']} / S {st['shorts']}"
                  f" · failed {app.failed}{app.degraded_text()}"
                  + (f" · universe ERROR {app.universe_error}"
                     if app.universe_error else ""))
            print("=" * 100)
            print(f"{'#':<3}{'DIR':<5}{'COIN':<15}{'PRICE':>13}{'24H%':>8}"
                  f"{'VOL24':>10}{'LEAN':>7}{'EARLY':>7}{'SCORE':>7}{'V3':>7}  FLAGS")
            print("-" * 100)

            shown = 0
            for c in rows:
                if shown >= 15:
                    break
                arrow = {"LONG": "▲", "SHORT": "▼"}.get(c.direction, "•")
                vol = c.quote_vol_24h
                vol_s = f"${vol/1e6:.1f}M" if vol >= 1e6 else f"${vol/1e3:.0f}K"
                flags = []
                v3_disp = f"{c.score_v3:>7.1f}" if getattr(c, "score_v3", None) is not None else "      —"
                print(f"{shown+1:<3}{arrow:<5}{c.coin:<15}{c.price:>13.8g}"
                      f"{c.change_24h_pct:>7.1f}%{vol_s:>10}{c.lean:>7.2f}"
                      f"{c.earlyness:>7.2f}{c.score:>7.1f}{v3_disp}  {' '.join(flags)}")
                shown += 1

            # Vetoed: excluded from ranking, still visible + shadow-logged.
            vet = app.vetoed()
            if vet:
                print("-" * 100)
                print(f" VETOED · {len(vet)} excluded from ranking, "
                      f"shadow-logged (top 5 by {app.sort_key})")
                for c in vet[:5]:
                    arrow = {"LONG": "▲", "SHORT": "▼"}.get(c.direction, "•")
                    codes = ",".join(v.code for v in c.vetoes)
                    v3v = f"{c.score_v3:>7.1f}" if getattr(c, "score_v3", None) is not None else "      —"
                print(f"   {arrow} {c.coin:<15}{c.score:>7.1f}{v3v}  veto:{codes}")

            top = next((c for c in rows if c.actionable), None)
            if top:
                plan, err = app.plan_for(top)
                print("-" * 100)
                print(f" TRADE PLAN · {top.coin} {top.direction} (review only)")
                if plan:
                    print(pl.format_plan(plan, top))
                else:
                    print(f"  no plan: {err}")

            sys.stdout.flush()
            n += 1
            if iterations is not None and n >= iterations:
                break
            time.sleep(app.args.interval)
    except KeyboardInterrupt:
        pass
    finally:
        from . import snapshot as _snap
        _snap.save(app.args.db, app.cards)
        app.store.close()
    return n


def main():
    ap = argparse.ArgumentParser(description="ALT RADAR live scanner")
    ap.add_argument("--stake", type=float, default=0.10)
    ap.add_argument("--coins", type=int, default=150)
    ap.add_argument("--interval", type=int, default=60)
    ap.add_argument("--db", default="data/signals.db")
    ap.add_argument("--log-threshold", type=float, default=24.0)
    ap.add_argument("--use-v3", action="store_true",
                    help="use score_v3 (shadow) for the flag threshold and "
                         "ranking instead of the v2 score. With this flag, "
                         "the log-threshold applies to score_v3 instead of score "
                         "(recommend: --use-v3 --log-threshold 40)")
    ap.add_argument("--write-logs", action="store_true", default=True)
    ap.add_argument("--no-logs", dest="write_logs", action="store_false")
    ap.add_argument("--headless", action="store_true",
                    help="print-only loop, no curses (for cron/systemd/pipes)")
    ap.add_argument("--iterations", type=int, default=None,
                    help="headless only: stop after N cycles")
    args = ap.parse_args()

    app = App(args)

    if args.headless:
        run_headless(app, args.iterations)
        return

    # Fall back to headless rather than dying if there is no usable terminal.
    if not sys.stdout.isatty() or not sys.stdin.isatty():
        print("no interactive TTY detected — running headless "
              "(use --headless to be explicit)", file=sys.stderr)
        run_headless(app, args.iterations)
        return

    try:
        curses.wrapper(app.loop)
    except curses.error as e:
        print(f"curses unavailable ({e}) — falling back to headless",
              file=sys.stderr)
        run_headless(app, args.iterations)

if __name__ == "__main__":
    main()
