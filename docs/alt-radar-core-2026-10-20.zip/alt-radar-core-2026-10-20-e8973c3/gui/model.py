"""Pure display logic for the ALT RADAR desktop GUI.

Contract (task G1 brief): NO tkinter import, NO network, NO threads — every
function in this module must be unit-testable without a display.

Nothing here re-derives scanner semantics:
  - sorting reuses proto.app.SORT_KEYS (score / early / lean / move / vol),
  - trade plans are rendered by proto.planner.format_plan,
  - the WATCH rule mirrors the TUI display rule (min_notional > stake).
Scoring, vetoes and the stake-aware flag gate live in proto.scorer /
proto.app and are NEVER forked in this module.
"""

from proto import planner as pl
from proto.app import SORT_KEYS  # sorting semantics shared with the TUI
from proto.planner import MAX_LEVERAGE
from proto.scorer import Scorecard, Veto, fits_stake
from proto.watcher_view import GROUP_KEYS, RESEARCH_BANNER

# Direction filters accepted by filter_cards / shown in the toolbar combo.
DIR_FILTERS = ("both", "long", "short")

# Outcome horizons, in display order (proto.outcomes.HORIZON_BARS keys).
HORIZONS = ("1h", "4h", "24h", "7d")

# Operator input bounds (brief: stake > 0, threshold 0-100, coins 10-581,
# interval >= 15s).
MIN_COINS, MAX_COINS = 10, 581
MIN_INTERVAL = 15


def direction_arrow(direction):
    """▲ / ▼ / • for a scorecard direction."""
    return {"LONG": "▲", "SHORT": "▼"}.get(direction, "•")


def format_shadow(card):
    """SHADOW column text: the v3 shadow score with its own side arrow, or
    an en dash when the shadow was not computed (older rows, thin history).
    Display only - the operator's rank and flags stay on the live score."""
    v = _to_float(getattr(card, "score_v3", None))
    if v is None:
        return "–"
    return f"{v:.1f} {direction_arrow(getattr(card, 'direction_v3', None))}"


def shadow_lines(card):
    """Detail-pane lines for the shadow score, or [] when not computed."""
    v = _to_float(getattr(card, "score_v3", None))
    if v is None:
        return []
    init = _to_float(getattr(card, "initiation", None))
    oi1 = _to_float(getattr(card, "oi_change_1h_pct", None))
    bits = [f"{v:.1f} {direction_arrow(getattr(card, 'direction_v3', None))} "
            f"{getattr(card, 'direction_v3', None) or 'n/a'}"]
    if init is not None:
        bits.append(f"initiation {init:.2f}")
    state = getattr(card, "flow_state", None)
    if state:
        bits.append(f"flow {state}"
                    + (f" (OI 1h {oi1:+.2f}%)" if oi1 is not None else ""))
    if getattr(card, "opening_for", None):
        bits.append("opening with the side")
    if getattr(card, "opening_against", None):
        bits.append("opening AGAINST the side")
    if getattr(card, "book_agree", None):
        bits.append("book agrees")
    crowd = getattr(card, "funding_crowd", None)
    if crowd and crowd != "neutral":
        bits.append(f"funding crowd {crowd}")
    return ["SHADOW SCORE (score-v3-dis) — not used for ranking or flags",
            "  " + " · ".join(bits), ""]


def _to_float(v):
    """float(v), or None for missing / garbage / non-finite venue values."""
    if v is None or isinstance(v, bool):
        return None
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    if f != f or f in (float("inf"), float("-inf")):
        return None
    return f


def format_price(p):
    """Price text: 8 significant digits, fixed decimals for sub-1e-4 prices.

    None / garbage / non-finite -> "n/a" (venue fields are untrusted text and
    a bad price must never crash a render).
    """
    f = _to_float(p)
    if f is None:
        return "n/a"
    if f == 0:
        return "0"
    if abs(f) < 1e-4:
        # Tiny prices must not render as scientific notation ("1.2e-07").
        return f"{f:.12f}".rstrip("0").rstrip(".")
    return f"{f:.8g}"


def format_oi(pct, notional=None):
    """OI cell: percent plus the dollars behind it.

    "+68.3% (~$12K)" — the notional (approx USDT open interest) is what
    separates real money arriving from a tiny base printing a big percent.
    "n/a" when the percent is missing (MEXC-only / unavailable).
    """
    f = _to_float(pct)
    if f is None:
        return "n/a"
    base = f"{f:+.1f}%"
    n = _to_float(notional)
    if n is None:
        return base
    return f"{base} (~{format_vol(n)})"


def format_vol(v):
    """24h quote volume text: $X.XM at >= 1M, $XK at >= 1K, $N below 1K."""
    f = _to_float(v)
    if f is None:
        return "n/a"
    if f >= 1e6:
        return f"${f / 1e6:.1f}M"
    if f >= 1e3:
        return f"${f / 1e3:.0f}K"
    return f"${f:.0f}"


def format_flags(card, stake):
    """Flags column text for one row, space separated ('' when nothing).

      WATCH        - venue minimum MARGIN is above the operator's stake
                     (min_notional at max leverage; same rule the TUI flags
                     column shows);
      UNVALIDATED  - Tier-2 marker for MEXC rows (no outcome history yet).
    """
    flags = []
    f_min = _to_float(getattr(card, "min_notional", None))
    f_stake = _to_float(stake)
    if (f_min is not None and f_stake is not None
            and not fits_stake(f_min, f_stake)):
        flags.append("WATCH")
    notes = getattr(card, "notes", None) or ()
    tier2 = any(isinstance(n, str) and "UNVALIDATED" in n for n in notes)
    if getattr(card, "venue", None) == "MEXC" or tier2:
        flags.append("UNVALIDATED")
    return " ".join(flags)


# Humanized labels for the vetoed table's REASON column (primary veto code
# only — proto.scorer.apply_vetoes' codes). Unknown codes pass through
# unchanged: a label is never invented for a code we do not know.
VETO_REASONS = {
    "low_volume": "Low volume",
    "late_move": "Late move",
    "wide_spread": "Wide spread",
    "thin_history": "Thin history",
}


def veto_reason(code):
    """Human label for one veto code: 'low_volume' -> 'Low volume'.

    Pure (no Tk, no network): falls back to the raw code for anything not
    in VETO_REASONS so a new scorer code still renders truthfully.
    """
    text = str(code)
    return VETO_REASONS.get(text, text)


def filter_cards(cards, dir_filter):
    """Direction filter: 'both' keeps everything, 'long'/'short' selects.

    Case-insensitive; unknown filters raise ValueError (operator inputs are
    validated, never silently ignored).
    """
    key = str(dir_filter).strip().lower()
    if key == "both":
        return list(cards)
    if key in ("long", "short"):
        want = key.upper()
        return [c for c in cards if c.direction == want]
    raise ValueError(f"unknown direction filter: {dir_filter!r}")


def filter_search(cards, text):
    """Coin substring filter (the search box): case-insensitive, trimmed.

    Empty/blank text keeps everything. Never raises — a search that matches
    nothing simply shows an empty table.
    """
    q = str(text or "").strip().upper()
    if not q:
        return list(cards)
    return [c for c in cards if q in str(getattr(c, "coin", "")).upper()]


def sort_cards(cards, key):
    """Sort a list with proto.app.SORT_KEYS semantics.

    Keys: score / early / lean / move / vol — the SAME lambdas the TUI and
    headless loop use (no fork). Unknown keys raise ValueError.
    """
    try:
        keyfunc = SORT_KEYS[key]
    except KeyError:
        raise ValueError(f"unknown sort key: {key!r}") from None
    return sorted(cards, key=keyfunc)


def split_vetoed(cards):
    """(ranked, vetoed): cards without vetoes / cards carrying vetoes.

    Input order is preserved — callers sort afterwards via sort_cards.
    """
    ranked, vetoed = [], []
    for c in cards:
        (vetoed if getattr(c, "vetoes", None) else ranked).append(c)
    return ranked, vetoed


def row_tags(direction, index, watch=False, vetoed=False):
    """Treeview tags for one row: direction tint x even/odd band.

    Pure (no Tk): returns tag names defined in gui/theme.py. Banding alternates
    strict even/odd by visible index; WATCH layers as foreground-only on top.
    """
    from gui import theme as _theme
    band = "_alt" if index % 2 == 0 else ""
    if vetoed:
        tags = [_theme.TAG_VETOED + band]
    elif direction == "LONG":
        tags = [_theme.TAG_LONG + band]
    elif direction == "SHORT":
        tags = [_theme.TAG_SHORT + band]
    else:
        tags = [_theme.TAG_PLAIN + band]
    if watch:
        tags.append(_theme.TAG_WATCH)
    return tuple(tags)


def snapshot_cards(rows):
    """Rebuild scorecards from Store.latest_rows() dicts (instant launch).

    Restores every display field the table and detail pane need (parts,
    vetoes with codes, OI percent + notional, economics). Per-signal notes
    (vol/price detail dicts) were never logged and stay absent — the detail
    pane shows the numbers, not the prose. Saved veto reasons read as the
    code itself (e.g. "late_move"), since only codes are logged.

    Rows arrive newest-scan-first by score; a coin appearing twice (two
    cycles inside the window) keeps its highest-scored row — the table
    addresses rows by coin and duplicates would collide.
    """
    cards = []
    seen = set()
    for r in rows:
        if r.get("coin") in seen:
            continue
        seen.add(r.get("coin"))
        sc = Scorecard(
            coin=r.get("coin", "?"), venue=r.get("venue") or "MEXC",
            score=r.get("score") or 0.0, lean=r.get("lean") or 0.0,
            direction=r.get("direction") or "NEUTRAL",
            earlyness=r.get("earlyness") or 0.0,
            funding_rate=r.get("funding_rate") or 0.0,
            oi_change_pct=r.get("oi_change_pct"),
            oi_notional=r.get("oi_notional"),
            price=r.get("price") or 0.0,
            change_24h_pct=r.get("change_24h_pct") or 0.0,
            quote_vol_24h=r.get("quote_vol_24h") or 0.0,
            spread_pct=r.get("spread_pct") or 0.0,
            min_notional=r.get("min_notional"))
        sc.magnitude_parts = {"VOL": r.get("mag_vol"), "BOOK": r.get("mag_book"),
                              "OI": r.get("mag_oi")}
        sc.lean_parts = {"VOL": r.get("lean_vol"), "BOOK": r.get("lean_book"),
                         "OI": r.get("lean_oi")}
        for _f in ("score_v3", "direction_v3", "initiation", "flow_state",
                   "oi_change_1h_pct", "opening_for", "opening_against",
                   "book_agree", "funding_crowd", "score_rule"):
            setattr(sc, _f, r.get(_f))
        sc.tradeable = bool(r.get("tradeable", True))
        codes = [c for c in str(r.get("veto_codes") or "").split(",") if c]
        sc.vetoes = [Veto(code=c, reason=c) for c in codes]
        cards.append(sc)
    return cards


def snapshot_label(rows):
    """'saved 14:02 (150 coins)' or '' when there is nothing saved."""
    if not rows:
        return ""
    import time
    n_coins = len({r.get("coin") for r in rows})
    saved_at = max((r.get("ts") or 0) for r in rows)
    return "saved %s (%d coins)" % (
        time.strftime("%H:%M", time.localtime(saved_at)), n_coins)


def load_file_snapshot(db_path):
    """Read the close-time snapshot only; safe and quick on the UI thread."""
    from proto import snapshot as snap
    cards, plans, saved_at = snap.load(db_path)
    if not cards:
        return [], {}, 0.0, ""
    import time as _t
    label = "saved %s (%d coins)" % (
        _t.strftime("%H:%M", _t.localtime(saved_at)), len(cards))
    return cards, plans, saved_at, label


def resolve_launch_snapshot(db_path):
    """("file"|"db"|"empty", cards, plans, label) for instant launch.

    Show whichever persisted source is newer: the close-time file (exact last
    screen, cached plans included) or the coin_state board (one row per coin,
    always coherent, no duplicates). Fall back to either source if the other
    is absent or unreadable. Only local reads.
    """
    file_cards, file_plans, saved_at, file_label = load_file_snapshot(db_path)
    db_rows = []
    try:
        from proto.store import Store
        store = Store(db_path)
        try:
            db_rows = store.current_rows()
        finally:
            try:
                store.close()
            except Exception:
                pass
    except Exception:
        db_rows = []

    db_at = max((r.get("ts") or 0 for r in db_rows), default=0)
    if db_rows and (not file_cards or db_at > (saved_at or 0)):
        db_label = snapshot_label(db_rows).replace("saved ", "scan ", 1)
        return "db", snapshot_cards(db_rows), {}, db_label
    if file_cards:
        return "file", file_cards, file_plans, file_label
    return "empty", [], {}, ""


def plan_text(card, plan):
    """Full trade-plan text via proto.planner.format_plan (never reimplemented)."""
    if plan is None:
        return "no plan available"
    return pl.format_plan(plan, card)


def outcome_summary(store):
    """Outcome-log summary for the outcomes panel.

      {"counts": {"1h": n, "4h": n, "24h": n, "7d": n},
       "total": n,
       "direction": {"LONG":  {"count", "avg_return", "hit_rate"},
                     "SHORT": {...}, ...}}

    avg_return = mean signed return (%) of resolved rows for that direction;
    hit_rate   = share of those resolved rows with a positive (in-favour)
    signed return, 0..1. `store=None` (or a store with no rows) yields the
    zero shape so the panel can render before any resolve has run.
    """
    zero = {"count": 0, "avg_return": 0.0, "hit_rate": 0.0}
    summary = {
        "counts": {h: 0 for h in HORIZONS},
        "total": 0,
        "direction": {"LONG": dict(zero), "SHORT": dict(zero)},
    }
    if store is None:
        return summary

    rows = store.conn.execute(
        "SELECT o.horizon, o.return_pct, s.direction"
        " FROM outcome_log o JOIN signal_log s ON s.id = o.signal_id"
    ).fetchall()
    rets_by_dir = {}
    for horizon, ret, direction in rows:
        summary["total"] += 1
        if horizon in summary["counts"]:
            summary["counts"][horizon] += 1
        ret = _to_float(ret)
        if ret is None:
            continue
        rets_by_dir.setdefault(direction, []).append(ret)

    for direction, rets in rets_by_dir.items():
        if not rets:
            continue
        wins = sum(1 for r in rets if r > 0)
        summary["direction"].setdefault(direction, dict(zero)).update(
            {"count": len(rets),
             "avg_return": sum(rets) / len(rets),
             "hit_rate": wins / len(rets)})
    return summary


def detail_text(card, plan=None, plan_err=None, stake=None, last_error=None):
    """Full detail-pane text for one scorecard (read-only, review-only).

    Mirrors the TUI detail view: score components (VOL/BOOK/OI mag+lean),
    earlyness / 24h / vol / spread / funding / OI lines, Tier-2 + funding-only
    notes, vetoes, counter-trend warnings, the last per-coin error, and the
    full trade plan rendered by pl.format_plan (which carries plan warnings).
    """
    out = []
    arrow = direction_arrow(card.direction)
    out.append(f"{card.coin}  {arrow} {card.direction}"
               f"   score {card.score:.1f}"
               f"   lean {card.lean:+.2f}"
               f"   earlyness {card.earlyness:.2f}")
    out.append(f"venue {card.venue} · tier 2 · READ-ONLY — this app places no orders")
    out.append("")

    out.append("SCORE COMPONENTS                 MAG      LEAN")
    for k in ("VOL", "BOOK", "OI"):
        mv = _to_float(card.magnitude_parts.get(k))
        lv = _to_float(card.lean_parts.get(k))
        mag = f"{mv * 100:.1f}" if mv is not None else "n/a"
        lean = f"{lv:+.2f}" if lv is not None else "n/a"
        out.append(f"  {k:<26} {mag:>10} {lean:>10}")
    out.append("")

    oi = _to_float(card.oi_change_pct)
    oi_n = _to_float(getattr(card, "oi_notional", None))
    out.append(f"  earlyness {card.earlyness:.2f}"
               f"   ·   24h {card.change_24h_pct:+.1f}%"
               f"   ·   vol24 {format_vol(card.quote_vol_24h)}"
               f"   ·   spread {card.spread_pct:.2f}%"
               f"   ·   funding {card.funding_rate * 100:+.4f}%"
               f"   ·   OIΔ {format_oi(oi, oi_n)}")
    if oi_n is not None:
        out.append(f"      (~{format_vol(oi_n)} open interest behind the move — "
                   f"judge the percent against this base)")
    if oi is None:
        out.append("  ⚠ OI unavailable on MEXC — OI/FUNDING signal is running on "
                   "funding alone")

    shadow = shadow_lines(card)
    if shadow:
        out.append("")
        out.extend(shadow[:-1])

    f_min = _to_float(card.min_notional)
    f_stake = _to_float(stake)
    if f_stake is not None:
        if f_min is None:
            out.append("  ⚠ minimum notional unknown — fails closed, this coin "
                       "never flags at any stake")
        elif not fits_stake(f_min, f_stake):
            out.append(f"  ⚠ min notional ${f_min:.4f} needs "
                       f"~${f_min / MAX_LEVERAGE:.4f} margin at "
                       f"{MAX_LEVERAGE}x > stake ${f_stake:.2f} — WATCH "
                       f"only until stake grows")
        else:
            out.append(f"  min notional ${f_min:.4f} (~${f_min / MAX_LEVERAGE:.4f} "
                       f"margin at {MAX_LEVERAGE}x) ≤ stake ${f_stake:.2f} — "
                       f"fits stake")

    notes = card.notes or ()
    if any(isinstance(n, str) and "UNVALIDATED" in n for n in notes):
        out.append("  ⚠ TIER 2 · UNVALIDATED — no outcome history exists for "
                   "this score yet; treat as experimental")
    if getattr(card, "venue", None) == "MEXC" and not any(
            isinstance(n, str) and "UNVALIDATED" in n for n in notes):
        out.append("  ⚠ TIER 2 · UNVALIDATED — MEXC row, no outcome history "
                   "for this score yet; treat as experimental")
    if last_error:
        out.append(f"  ⚠ last error: {last_error}")
    out.append("")

    if card.vetoes:
        out.append("VETOES")
        for v in card.vetoes:
            out.append(f"  ⨯ {v.code}: {v.reason}")
        out.append("")

    counters = [n for n in notes
                if isinstance(n, str) and (n.startswith("counter-trend:") or
                                           n.startswith("MTF ") or
                                           n.startswith("DATA "))]
    if counters:
        out.append("WARNINGS")
        for n in counters:
            out.append(f"  ⚠ {n}")
        out.append("")

    out.append("TRADE PLAN (review only — this app places no orders)")
    if plan is not None:
        out.append(plan_text(card, plan))
    elif plan_err:
        out.append(f"  no plan: {plan_err}")
    else:
        out.append("  no plan available (fetching…)")
    return "\n".join(out)


# ---------------------------------------------------------------------------
# Operator input validation (brief: invalid input -> a status-bar message,
# never a crash). Each returns the parsed value or raises ValueError with a
# message that can be shown verbatim in the status bar.
# ---------------------------------------------------------------------------

def validate_stake(value):
    f = _to_float(value)
    if f is None or f <= 0:
        raise ValueError(f"stake must be a number > 0, got {value!r}")
    return f


def validate_threshold(value):
    f = _to_float(value)
    if f is None or not 0 <= f <= 100:
        raise ValueError(f"log threshold must be between 0 and 100, got {value!r}")
    return f


def validate_coins(value):
    f = _to_float(value)
    if f is None or f != int(f):
        raise ValueError(f"coins must be a whole number, got {value!r}")
    v = int(f)
    if not MIN_COINS <= v <= MAX_COINS:
        raise ValueError(f"coins must be between {MIN_COINS} and {MAX_COINS}, got {value!r}")
    return v


def validate_interval(value):
    f = _to_float(value)
    if f is None or f != int(f):
        raise ValueError(f"interval must be a whole number of seconds, got {value!r}")
    v = int(f)
    if v < MIN_INTERVAL:
        raise ValueError(f"interval must be at least {MIN_INTERVAL}s, got {value!r}")
    return v


# ---------------------------------------------------------------------------
# Watcher panel (display only, Task 7). Research-labeled text lines for
# watcher_setup rows. Scanner sorting, ranking and flags are never touched
# here; the Qt watcher dock (qtgui/app.py, watcher UI Task 5) renders these
# same helpers — the report-only deferral is landed.
# ---------------------------------------------------------------------------

def watcher_row_text(row):
    """One-line display for a watcher_setup mapping (dict or row-like).

    ``'AAA LONG active ev=+0.41 [SHADOW]'``; missing numbers render n/a,
    funding-unavailable rows carry FUND?. Pure (no Tk, no network).
    """
    if not isinstance(row, dict):
        try:
            row = dict(row)
        except (TypeError, ValueError):
            return "n/a"
    coin = row.get("coin", "?")
    direction = row.get("direction", "?")
    state = row.get("state", "?")
    sub = row.get("substate")
    if sub:
        state = f"{state}/{sub}"
    ev = row.get("ev_r")
    ev_txt = "n/a" if ev is None else f"{float(ev):+.2f}"
    bits = [f"{coin} {direction} {state} ev={ev_txt}"]
    if row.get("shadow_selected"):
        bits.append("[SHADOW]")
    if (row.get("funding") or row.get("funding_state")) == "unavailable":
        bits.append("[FUND?]")
    return " ".join(bits)


def watcher_panel_lines(rows, paused=False, disabled=()):
    """Research-labeled panel lines for an iterable of watcher_setup
    mappings. Display only: order preserved, nothing ranked or flagged."""
    lines = ["WATCHER (research, shadow-only — scanner untouched; no orders)"]
    if disabled:
        lines[0] += f" [disabled: {','.join(disabled)}]"
    if paused:
        lines[0] += " [PAUSED]"
    rows = list(rows or [])
    if not rows:
        return lines + ["  no watcher setups"]
    return lines + [f"  {watcher_row_text(r)}" for r in rows]


def watcher_order(panel):
    """Setup ids, active first — the single order every watcher surface
    walks (selection indexes this, never row position).

    Pure (no Tk, no network): walks the shared view-model's groups in
    GROUP_KEYS order, the same order proto.app.App.watcher_order uses.
    """
    groups = getattr(panel, "groups", {}) or {}
    order = []
    for key in GROUP_KEYS:
        order.extend(groups.get(key, ()))
    return list(order)


def _watcher_px(v):
    return f"{v:.8g}" if isinstance(v, (int, float)) else "—"


def watcher_detail_text(panel, selected_id=None):
    """Full watcher-detail text for one setup id (read-only, review-only).

    Pure (no Tk, no network): renders the shared view-model's detail dict
    with STATE_WORDS verbs verbatim, the panel notices (research banner
    first), and data-as-of stamps. A None panel renders the contained
    "watcher data unavailable" fallback; an empty panel renders the
    silence-valid line. Missing numbers render "—", never invented.
    """
    if panel is None:
        return ("watcher data unavailable — scanner intact\n"
                "  (DB missing or locked; the scan table above is unaffected)")
    notices = list(getattr(panel, "notices", None) or [RESEARCH_BANNER])
    by_id = getattr(panel, "by_id", None) or {}
    sid = selected_id if selected_id is not None else getattr(
        panel, "selected_id", None)
    d = by_id.get(sid)
    if d is None:
        lines = list(notices) + [""]
        if not by_id:
            lines.append("no active setups — silence is valid")
        else:
            lines.append("select a setup for the full breakdown")
        lines.append(_watcher_asof_line(panel))
        return "\n".join(lines)
    cost = d.get("cost") or {}
    lines = list(notices) + [""]
    lines.append(f"{d.get('coin', '?')} {d.get('direction', '?')} · "
                 f"{d.get('state', '?')}")
    lines.append(f"  rule {d.get('rule', '?')} · src bar "
                 f"{d.get('src_bar_ts', '?')} · monitoring "
                 f"{d.get('monitoring', '?')}")
    lines.append(f"  entry {_watcher_px(d.get('entry'))} · stop "
                 f"{_watcher_px(d.get('stop_px'))} · tgt "
                 f"{_watcher_px(d.get('tgt_px'))} · invalid "
                 f"{_watcher_px(d.get('invalid_price'))}")
    lines.append(f"  state {d.get('state', '?')}")
    if d.get("missing"):
        lines.append(f"  missing/stale: {', '.join(map(str, d['missing']))}")
    lines.append(f"  cost total {cost.get('total', '?')} · floor "
                 f"{cost.get('floor', '?')} · funding "
                 f"{cost.get('funding_state', '?')}")
    lines.append(f"  ev_r {d.get('ev_r', '?')} · p_lb {d.get('p_lb', '?')} · "
                 f"shadow {'yes' if d.get('shadow_selected') else 'no'}")
    lines.append(f"  {_watcher_asof_line(panel)}")
    return "\n".join(lines)


def _watcher_asof_line(panel):
    asof = getattr(panel, "asof_ts", 0)
    last = getattr(panel, "last_bar_ts", None)
    text = f"data as of {asof}" if asof else "no data yet"
    if last is not None:
        text += f" · last closed bar {last}"
    return text
